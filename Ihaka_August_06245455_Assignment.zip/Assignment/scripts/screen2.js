function buildScreen2(){
  screen2 = new createjs.Container();

var timeline2 = new createjs.Timeline( {loop: false} );

var placekick = new createjs.Text("Place Kick", "30px Arial Bold", "white");
  placekick.x = 700;
  placekick.y = 50;
  timeline2.addTween(createjs.Tween.get(placekick)
    .wait(2000)
    .to({ x: 300 }, 3000, createjs.Ease.cubicOut));

var field2 = new createjs.Bitmap("images/field.png");
  field2.x = 750;
  field2.y = 100;
  field2.regX = 34;
  field2.regY = 34;

  timeline2.addTween(createjs.Tween.get(field2)
    .wait(2000)
    .to({ x: 100 }, 3000, createjs.Ease.cubicOut));

var player3 = new createjs.Shape();
  player3.graphics.beginFill("black").drawRect(0, 0, 10, 30);
  player3.x = 330;  player3.y = 200;
  timeline2.addTween(createjs.Tween.get(player3)
    .wait(3000)
    .to({ alpha: 0, visible: true }, 0)
    .to({ alpha: 1.0}, 3000)
    .to({ alpha: 1.0, x:327, y:197 }, 500, createjs.Ease.cubicOut)
    .to({ alpha: 1.0, x:330 , y:200 }, 300, createjs.Ease.cubicOut));

var ball2 = new createjs.Shape();
  ball2.graphics.beginFill("red").drawRect(0, 0, 5, 10);
  ball2.x = 333;  ball2.y = 220;
  timeline2.addTween(createjs.Tween.get(ball2)
    .wait(3000)
    .to({ alpha: 0, visible: true }, 0)
    .to({ alpha: 1.0}, 3000)
    .wait(500)
    .to({ alpha: 1.0, x:700, y:200 }, 3000, createjs.Ease.cubicOut));

  player3.visible = false;
  ball2.visible = false;

var click3 = new createjs.Text("", "16px Arial", "#FFF");
  click3.x = 50;
  click3.y = 250;
  click3.text = "Screen 2";

timeline2.setPaused(true);

  click3.addEventListener("click", function(){
  screen2.addChild(placekick);
  screen2.addChild(field2);
  screen2.addChild(player3);
  screen2.addChild(ball2);
  screen2.addChild(click4);
  timeline2.gotoAndPlay(0);
  })

  screen2.addChild(click3)

var click4 = new createjs.Text("", "16px Arial", "#FFF");
  click4.x = 50;
  click4.y = 300;
  click4.text = "Next Screen";

  click4.addEventListener("click", function(){
  stage.removeChild(screen2);
  stage.addChild(screen3);
  })

  screen2.addChild(click4);
}
